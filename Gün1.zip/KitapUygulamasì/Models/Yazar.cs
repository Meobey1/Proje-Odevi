﻿namespace KitapUygulaması.Models
{
    public class Yazar
    {
        public int Id { get; set; } 
        public string Name { get; set; }
        public int KitapSayisi { get; set; }
        public int YazarPuani { get; set; }

    }
}
